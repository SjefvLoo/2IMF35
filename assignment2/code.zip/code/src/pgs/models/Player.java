package pgs.models;

public enum Player {
    EVEN,
    ODD,
    ;
}
